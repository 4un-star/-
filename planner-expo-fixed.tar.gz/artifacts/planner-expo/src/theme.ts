export const colors = {
  primary: "#6b7e6e",
  primaryLight: "#e8ede9",
  background: "#fafaf8",
  card: "#ffffff",
  text: "#1a1a1a",
  textSecondary: "#6b7280",
  border: "#e5e7eb",
  destructive: "#ef4444",
  destructiveLight: "#fee2e2",
  success: "#22c55e",
  warning: "#f97316",
  white: "#ffffff",
  muted: "#f3f4f6",
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
};

export const radius = {
  sm: 8,
  md: 12,
  lg: 16,
  full: 9999,
};

export const fontSize = {
  xs: 12,
  sm: 14,
  md: 16,
  lg: 18,
  xl: 22,
  xxl: 28,
};

export const shadow = {
  card: {
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.06,
    shadowRadius: 4,
    elevation: 2,
  },
};
