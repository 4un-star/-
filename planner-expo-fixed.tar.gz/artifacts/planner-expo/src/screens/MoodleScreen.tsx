import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useSQLiteContext } from "expo-sqlite";
import { useQueryClient } from "@tanstack/react-query";
import { Ionicons } from "@expo/vector-icons";
import { format } from "date-fns";
import { ru } from "date-fns/locale";

import {
  upsertMoodleTasks,
  getMoodleCache,
  setMoodleCache,
  getAllTasks,
} from "@/db";
import {
  syncMoodle,
  detectScheduleChanges,
  MoodleGrade,
  MissingAssignment,
  CalendarEvent,
} from "@/api/moodle";
import { useAuth } from "@/context/AuthContext";
import { colors, spacing, radius, fontSize, shadow } from "@/theme";
import {
  notifyScheduleChange,
  scheduleDeadlineNotifications,
} from "@/notifications";

const MONTHS: Record<number, string> = {
  0: "Январь", 1: "Февраль", 2: "Март", 3: "Апрель",
  4: "Май", 5: "Июнь", 6: "Июль", 7: "Август",
  8: "Сентябрь", 9: "Октябрь", 10: "Ноябрь", 11: "Декабрь",
};

function Section({
  icon,
  title,
  children,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <View style={[styles.card, shadow.card]}>
      <View style={styles.cardHeader}>
        <Ionicons name={icon} size={18} color={colors.primary} />
        <Text style={styles.cardTitle}>{title}</Text>
      </View>
      {children}
    </View>
  );
}

export default function MoodleScreen() {
  const db = useSQLiteContext();
  const queryClient = useQueryClient();
  const { user } = useAuth();

  const [isSyncing, setIsSyncing] = useState(false);

  const missedHours: Record<string, number> = JSON.parse(
    getMoodleCache(db, "missedHours") ?? "{}"
  );
  const grades: MoodleGrade[] = JSON.parse(
    getMoodleCache(db, "grades") ?? "[]"
  );
  const missingAssignments: MissingAssignment[] = JSON.parse(
    getMoodleCache(db, "missingAssignments") ?? "[]"
  );
  const lastSyncAt = getMoodleCache(db, "lastSyncAt");

  const now = new Date();
  const currentMonthKey = `${MONTHS[now.getMonth()]} ${now.getFullYear()}`;
  const thisMonthMissed = missedHours[currentMonthKey] ?? null;
  const totalMissed = Object.values(missedHours).reduce((a, b) => a + b, 0);

  const handleSync = async () => {
    if (!user?.username || !user?.password) {
      Alert.alert("Ошибка", "Необходимо войти в аккаунт заново");
      return;
    }
    setIsSyncing(true);
    try {
      const result = await syncMoodle(user.username, user.password);

      upsertMoodleTasks(db, result.tasks);

      setMoodleCache(db, "missedHours", JSON.stringify(result.missedHours));
      setMoodleCache(db, "grades", JSON.stringify(result.grades));
      setMoodleCache(db, "missingAssignments", JSON.stringify(result.missingAssignments));
      setMoodleCache(db, "calendarEvents", JSON.stringify(result.calendarEvents));
      setMoodleCache(db, "lastSyncAt", new Date().toISOString());

      const prevEventsRaw = getMoodleCache(db, "prevCalendarEvents");
      if (prevEventsRaw) {
        const prevEvents: CalendarEvent[] = JSON.parse(prevEventsRaw);
        const changes = detectScheduleChanges(result.calendarEvents, prevEvents);
        if (changes.length > 0) {
          await notifyScheduleChange(changes);
          setMoodleCache(db, "scheduleChanges", JSON.stringify(changes));
        }
      }
      setMoodleCache(db, "prevCalendarEvents", JSON.stringify(result.calendarEvents));

      const allTasks = getAllTasks(db);
      await scheduleDeadlineNotifications(allTasks);

      queryClient.invalidateQueries({ queryKey: ["tasks"] });
      queryClient.invalidateQueries({ queryKey: ["stats"] });
      queryClient.invalidateQueries({ queryKey: ["risks"] });

      const methodLabel = result.method === "api" ? "Moodle API" : "веб-скрейпинг";
      Alert.alert(
        "Синхронизация завершена",
        [
          `Задач загружено: ${result.tasks.length}`,
          `Оценок найдено: ${result.grades.length}`,
          `Несданных работ: ${result.missingAssignments.length}`,
          `Метод: ${methodLabel}`,
        ].join("\n")
      );
    } catch (err: any) {
      Alert.alert(
        "Ошибка синхронизации",
        err.message ?? "Проверьте подключение к интернету."
      );
    } finally {
      setIsSyncing(false);
    }
  };

  const gradesByCourse = grades.reduce(
    (acc: Record<string, MoodleGrade[]>, g) => {
      const key = g.courseName;
      if (!acc[key]) acc[key] = [];
      acc[key].push(g);
      return acc;
    },
    {}
  );

  function gradeColor(g: number | null, max: number): string {
    if (g === null) return colors.textSecondary;
    if (max < 5) {
      const pct = (g / max) * 100;
      if (pct < 40) return colors.destructive;
      if (pct < 70) return "#d97706";
      return colors.success;
    }
    if (g < 3) return colors.destructive;
    if (g < 4) return "#d97706";
    return colors.success;
  }

  function gradeLabel(g: number | null): string {
    if (g === null) return "—";
    return Number.isInteger(g) ? String(g) : g.toFixed(1);
  }

  const scheduleChanges: string[] = JSON.parse(
    getMoodleCache(db, "scheduleChanges") ?? "[]"
  );

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.heading}>Moodle</Text>
        <Text style={styles.subheading}>
          Прямое подключение к moodle.preco.ru
        </Text>

        {thisMonthMissed !== null && (
          <View
            style={[
              styles.banner,
              thisMonthMissed >= 18 && styles.bannerDanger,
            ]}
          >
            <Ionicons
              name="alert-circle-outline"
              size={20}
              color={thisMonthMissed >= 18 ? colors.destructive : "#d97706"}
            />
            <View style={styles.bannerText}>
              <Text
                style={[
                  styles.bannerHours,
                  { color: thisMonthMissed >= 18 ? colors.destructive : "#d97706" },
                ]}
              >
                {thisMonthMissed} ч. в {MONTHS[now.getMonth()].toLowerCase()}
              </Text>
              <Text style={styles.bannerSub}>
                {thisMonthMissed >= 20
                  ? `ВЫГОВОР — лимит 18 ч. превышен на ${thisMonthMissed - 18} ч.`
                  : thisMonthMissed >= 18
                  ? `Лимит 18 ч. превышен · до выговора ${20 - thisMonthMissed} ч.`
                  : `Лимит 18 ч./мес · осталось ${18 - thisMonthMissed} ч. · всего ${totalMissed} ч.`}
              </Text>
            </View>
          </View>
        )}

        {scheduleChanges.length > 0 && (
          <View style={styles.changesBanner}>
            <Ionicons name="calendar-outline" size={18} color="#7c3aed" />
            <View style={{ flex: 1 }}>
              <Text style={styles.changesTitle}>
                Изменения в расписании ({scheduleChanges.length})
              </Text>
              {scheduleChanges.map((c, i) => (
                <Text key={i} style={styles.changesItem}>
                  • {c}
                </Text>
              ))}
            </View>
          </View>
        )}

        <Section icon="refresh-outline" title="Синхронизация">
          <Text style={styles.cardSub}>
            Загружает задачи, оценки, несданные работы, пропущенные часы и
            изменения расписания из Moodle
          </Text>

          <View style={[styles.accountRow]}>
            <Ionicons name="person-circle-outline" size={20} color={colors.primary} />
            <Text style={styles.accountText}>
              {user?.username ?? "—"}
            </Text>
          </View>

          <TouchableOpacity
            style={[styles.syncBtn, isSyncing && styles.btnDisabled]}
            onPress={handleSync}
            disabled={isSyncing}
            activeOpacity={0.8}
          >
            {isSyncing ? (
              <>
                <ActivityIndicator color={colors.white} size="small" />
                <Text style={styles.syncBtnText}>Синхронизация…</Text>
              </>
            ) : (
              <>
                <Ionicons name="refresh-outline" size={18} color={colors.white} />
                <Text style={styles.syncBtnText}>Синхронизировать с Moodle</Text>
              </>
            )}
          </TouchableOpacity>

          {lastSyncAt && (
            <Text style={styles.lastSync}>
              Последняя:{" "}
              {format(new Date(lastSyncAt), "d MMMM, HH:mm", { locale: ru })}
            </Text>
          )}
        </Section>

        <Section icon="school-outline" title="Оценки">
          {Object.keys(gradesByCourse).length === 0 ? (
            <Text style={styles.noData}>
              Нет данных — нажмите «Синхронизировать»
            </Text>
          ) : (
            Object.entries(gradesByCourse).map(([course, items]) => (
              <View key={course} style={styles.courseBlock}>
                <Text style={styles.courseName}>{course}</Text>
                {items.map((item, idx) => (
                  <View key={idx} style={styles.gradeRow}>
                    <Text style={styles.gradeItem} numberOfLines={1}>
                      {item.itemName}
                    </Text>
                    <View
                      style={[
                        styles.gradeBadge,
                        { backgroundColor: gradeColor(item.grade, item.gradeMax) + "20" },
                      ]}
                    >
                      <Text
                        style={[
                          styles.gradeValue,
                          { color: gradeColor(item.grade, item.gradeMax) },
                        ]}
                      >
                        {gradeLabel(item.grade)}
                        {item.grade !== null ? `/${item.gradeMax}` : ""}
                      </Text>
                    </View>
                  </View>
                ))}
              </View>
            ))
          )}
        </Section>

        <Section icon="document-text-outline" title="Несданные работы">
          {missingAssignments.length === 0 ? (
            <Text style={styles.noData}>
              {grades.length > 0
                ? "Нет просроченных заданий — отлично!"
                : "Нет данных — нажмите «Синхронизировать»"}
            </Text>
          ) : (
            missingAssignments
              .sort((a, b) => b.daysOverdue - a.daysOverdue)
              .map((a, i) => (
                <View key={i} style={styles.missingRow}>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.missingName} numberOfLines={1}>
                      {a.name}
                    </Text>
                    <Text style={styles.missingCourse}>{a.courseName}</Text>
                  </View>
                  <View
                    style={[
                      styles.overdueBadge,
                      a.daysOverdue >= 7 && styles.overdueBadgeDanger,
                    ]}
                  >
                    <Text
                      style={[
                        styles.overdueText,
                        a.daysOverdue >= 7 && styles.overdueTextDanger,
                      ]}
                    >
                      +{a.daysOverdue} дн.
                    </Text>
                  </View>
                </View>
              ))
          )}
        </Section>

        <Section icon="time-outline" title="Пропущенные часы по месяцам">
          {Object.keys(missedHours).length === 0 ? (
            <Text style={styles.noData}>
              Нет данных — нажмите «Синхронизировать»
            </Text>
          ) : (
            <View style={styles.monthList}>
              {Object.entries(missedHours).map(([month, hours]) => {
                const isCurrent = month === currentMonthKey;
                const isDangerous = Number(hours) > 8;
                return (
                  <View
                    key={month}
                    style={[
                      styles.monthRow,
                      isCurrent && styles.monthRowCurrent,
                    ]}
                  >
                    <View style={styles.monthNameRow}>
                      <Text
                        style={[
                          styles.monthName,
                          isCurrent && { color: colors.primary },
                        ]}
                      >
                        {month}
                      </Text>
                      {isCurrent && (
                        <View style={styles.currentBadge}>
                          <Text style={styles.currentBadgeText}>сейчас</Text>
                        </View>
                      )}
                    </View>
                    <View
                      style={[
                        styles.hoursBadge,
                        isDangerous && styles.hoursBadgeDanger,
                      ]}
                    >
                      <Text
                        style={[
                          styles.hoursText,
                          isDangerous && styles.hoursTextDanger,
                        ]}
                      >
                        {hours} ч. / {Math.round(Number(hours) / 2)} пар
                      </Text>
                    </View>
                  </View>
                );
              })}
              <View style={styles.totalRow}>
                <Text style={styles.totalLabel}>Итого</Text>
                <View
                  style={[
                    styles.hoursBadge,
                    totalMissed >= 36 && styles.hoursBadgeDanger,
                  ]}
                >
                  <Text
                    style={[
                      styles.hoursText,
                      totalMissed >= 36 && styles.hoursTextDanger,
                    ]}
                  >
                    {totalMissed} ч. / {Math.round(totalMissed / 2)} пар
                  </Text>
                </View>
              </View>
            </View>
          )}
        </Section>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background },
  content: { padding: spacing.lg, gap: spacing.md },
  heading: { fontSize: fontSize.xxl, fontWeight: "600", color: colors.text },
  subheading: {
    fontSize: fontSize.sm,
    color: colors.textSecondary,
    marginTop: -spacing.sm,
  },
  banner: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: spacing.sm,
    padding: spacing.md,
    borderRadius: radius.md,
    backgroundColor: "#fff8e7",
    borderWidth: 1,
    borderColor: "#f59e0b50",
  },
  bannerDanger: {
    backgroundColor: colors.destructiveLight,
    borderColor: colors.destructive + "50",
  },
  bannerText: { flex: 1 },
  bannerHours: { fontSize: fontSize.md, fontWeight: "700" },
  bannerSub: { fontSize: fontSize.xs, color: colors.textSecondary, marginTop: 2 },
  changesBanner: {
    flexDirection: "row",
    gap: spacing.sm,
    padding: spacing.md,
    borderRadius: radius.md,
    backgroundColor: "#f5f3ff",
    borderWidth: 1,
    borderColor: "#7c3aed30",
  },
  changesTitle: {
    fontSize: fontSize.sm,
    fontWeight: "600",
    color: "#7c3aed",
    marginBottom: 4,
  },
  changesItem: { fontSize: fontSize.xs, color: colors.textSecondary },
  card: {
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    padding: spacing.lg,
    gap: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  cardHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.xs,
  },
  cardTitle: { fontSize: fontSize.lg, fontWeight: "600", color: colors.text },
  cardSub: {
    fontSize: fontSize.sm,
    color: colors.textSecondary,
    marginTop: -spacing.sm,
  },
  accountRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    backgroundColor: colors.muted,
    borderRadius: radius.sm,
  },
  accountText: {
    fontSize: fontSize.md,
    color: colors.text,
    fontWeight: "500",
  },
  syncBtn: {
    backgroundColor: colors.primary,
    borderRadius: radius.sm,
    paddingVertical: 14,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    gap: spacing.sm,
  },
  btnDisabled: { opacity: 0.5 },
  syncBtnText: { color: colors.white, fontSize: fontSize.md, fontWeight: "600" },
  lastSync: {
    fontSize: fontSize.xs,
    color: colors.textSecondary,
    textAlign: "center",
  },
  noData: { fontSize: fontSize.sm, color: colors.textSecondary },
  courseBlock: { gap: spacing.xs },
  courseName: {
    fontSize: fontSize.sm,
    fontWeight: "600",
    color: colors.text,
    marginBottom: 2,
  },
  gradeRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 4,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  gradeItem: {
    flex: 1,
    fontSize: fontSize.xs,
    color: colors.textSecondary,
    marginRight: spacing.sm,
  },
  gradeBadge: {
    borderRadius: radius.sm,
    paddingHorizontal: spacing.sm,
    paddingVertical: 2,
    minWidth: 48,
    alignItems: "center",
  },
  gradeValue: { fontSize: fontSize.xs, fontWeight: "700" },
  missingRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    gap: spacing.sm,
  },
  missingName: {
    fontSize: fontSize.sm,
    fontWeight: "500",
    color: colors.text,
  },
  missingCourse: { fontSize: fontSize.xs, color: colors.textSecondary },
  overdueBadge: {
    backgroundColor: "#fff8e7",
    borderRadius: radius.sm,
    paddingHorizontal: spacing.sm,
    paddingVertical: 4,
  },
  overdueBadgeDanger: { backgroundColor: colors.destructiveLight },
  overdueText: {
    fontSize: fontSize.xs,
    fontWeight: "700",
    color: "#d97706",
  },
  overdueTextDanger: { color: colors.destructive },
  monthList: { gap: 2 },
  monthRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  monthRowCurrent: { backgroundColor: colors.primaryLight + "40" },
  monthNameRow: { flexDirection: "row", alignItems: "center", gap: spacing.xs },
  monthName: { fontSize: fontSize.sm, color: colors.text },
  currentBadge: {
    backgroundColor: colors.primaryLight,
    borderRadius: radius.sm,
    paddingHorizontal: 6,
    paddingVertical: 2,
  },
  currentBadgeText: { fontSize: 10, color: colors.primary, fontWeight: "600" },
  hoursBadge: {
    backgroundColor: colors.muted,
    borderRadius: radius.sm,
    paddingHorizontal: spacing.sm,
    paddingVertical: 4,
  },
  hoursBadgeDanger: { backgroundColor: colors.destructiveLight },
  hoursText: { fontSize: fontSize.xs, fontWeight: "600", color: colors.textSecondary },
  hoursTextDanger: { color: colors.destructive },
  totalRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingTop: spacing.sm,
    marginTop: 2,
  },
  totalLabel: { fontSize: fontSize.sm, fontWeight: "700", color: colors.text },
});
