/**
 * Moodle direct client — запросы идут с телефона напрямую на moodle.preco.ru.
 * React Native's fetch не поддерживает redirect: "manual" — используем
 * автоматические редиректы и проверяем финальный URL / HTML.
 */

import { Task } from "@/db";

const BASE = "https://moodle.preco.ru";

const HEADERS = {
  "User-Agent":
    "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36",
  Accept:
    "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
  "Accept-Language": "ru-RU,ru;q=0.8,en-US;q=0.5,en;q=0.3",
};

// ── Cookie jar ───────────────────────────────────────────────────────────────

class CookieJar {
  private store: Map<string, string> = new Map();

  set(header: string | null): void {
    if (!header) return;
    for (const part of header.split(",")) {
      const seg = part.trim().split(";")[0].trim();
      const eq = seg.indexOf("=");
      if (eq > 0) {
        this.store.set(seg.slice(0, eq).trim(), seg.slice(eq + 1).trim());
      }
    }
  }

  header(): string {
    return Array.from(this.store.entries())
      .map(([k, v]) => `${k}=${v}`)
      .join("; ");
  }

  has(key: string): boolean {
    return this.store.has(key);
  }

  clear(): void {
    this.store.clear();
  }
}

const jar = new CookieJar();

// ── Types ────────────────────────────────────────────────────────────────────

export interface MoodleGrade {
  courseId: number;
  courseName: string;
  itemName: string;
  grade: number | null;
  gradeMax: number;
}

export interface MissingAssignment {
  courseId: number;
  courseName: string;
  name: string;
  dueDate: string;
  daysOverdue: number;
}

export interface CalendarEvent {
  id: number;
  name: string;
  timestart: number;
  eventtype: string;
  courseName?: string;
}

export interface MoodleSyncResult {
  tasks: Task[];
  missedHours: Record<string, number>;
  grades: MoodleGrade[];
  missingAssignments: MissingAssignment[];
  calendarEvents: CalendarEvent[];
  method: "api" | "scraping";
}

// ── Moodle REST API ───────────────────────────────────────────────────────────

async function getMobileToken(
  username: string,
  password: string
): Promise<string | null> {
  try {
    const res = await fetch(`${BASE}/login/token.php`, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: `username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}&service=moodle_mobile_app`,
    });
    const data = await res.json();
    if (data?.token && typeof data.token === "string") return data.token;
    return null;
  } catch {
    return null;
  }
}

async function moodleRest(
  token: string,
  wsfunction: string,
  params: Record<string, string | number> = {}
): Promise<any> {
  const query = new URLSearchParams({
    wstoken: token,
    wsfunction,
    moodlewsrestformat: "json",
    ...Object.fromEntries(
      Object.entries(params).map(([k, v]) => [k, String(v)])
    ),
  });
  const res = await fetch(
    `${BASE}/webservice/rest/server.php?${query.toString()}`
  );
  return res.json();
}

async function fetchTasksViaApi(token: string): Promise<Task[]> {
  try {
    const data = await moodleRest(
      token,
      "core_calendar_get_calendar_upcoming_view",
      {}
    );
    const events: any[] = data?.events ?? [];
    return events
      .filter((ev) => ev.id && ev.timestart)
      .map((ev) => ({
        id: `moodle_${ev.id}`,
        title: ev.name ?? "Без названия",
        description: ev.description
          ? ev.description.replace(/<[^>]+>/g, "").trim().slice(0, 300)
          : null,
        date: new Date(ev.timestart * 1000).toISOString(),
        type: mapEventType(ev.eventtype ?? ""),
        subject: ev.course?.shortname ?? ev.modulename ?? "Moodle",
        completed: false,
        notificationDays: 1,
        source: "moodle" as const,
        createdAt: new Date().toISOString(),
      }));
  } catch {
    return [];
  }
}

async function fetchCalendarEvents(token: string): Promise<CalendarEvent[]> {
  try {
    const data = await moodleRest(
      token,
      "core_calendar_get_calendar_upcoming_view",
      {}
    );
    return (data?.events ?? []).map((ev: any) => ({
      id: ev.id,
      name: ev.name,
      timestart: ev.timestart,
      eventtype: ev.eventtype,
      courseName: ev.course?.shortname,
    }));
  } catch {
    return [];
  }
}

async function fetchGradesAndAssignments(
  token: string
): Promise<{ grades: MoodleGrade[]; missingAssignments: MissingAssignment[] }> {
  const grades: MoodleGrade[] = [];
  const missingAssignments: MissingAssignment[] = [];

  try {
    const siteInfo = await moodleRest(token, "core_webservice_get_site_info", {});
    const userId = siteInfo?.userid;
    if (!userId) return { grades, missingAssignments };

    const coursesData = await moodleRest(
      token,
      "core_enrol_get_users_courses",
      { userid: userId }
    );
    const courses: any[] = Array.isArray(coursesData)
      ? coursesData.slice(0, 10)
      : [];

    const now = Math.floor(Date.now() / 1000);

    await Promise.allSettled(
      courses.map(async (course) => {
        try {
          const gd = await moodleRest(
            token,
            "gradereport_user_get_grade_items",
            { courseid: course.id, userid: userId }
          );
          for (const item of gd?.usergrades?.[0]?.gradeitems ?? []) {
            if (item.itemtype === "mod" && item.itemname) {
              grades.push({
                courseId: course.id,
                courseName: course.shortname || course.displayname || "Курс",
                itemName: item.itemname,
                grade: item.graderaw ?? null,
                gradeMax: item.grademax ?? 100,
              });
            }
          }
        } catch {}

        try {
          const ad = await moodleRest(token, "mod_assign_get_assignments", {
            "courseids[0]": course.id,
          });
          for (const c of ad?.courses ?? []) {
            for (const assign of c?.assignments ?? []) {
              if (assign.duedate && assign.duedate > 0 && assign.duedate < now) {
                const daysOverdue = Math.floor((now - assign.duedate) / 86400);
                if (daysOverdue <= 45) {
                  const hasGrade = grades.some(
                    (g) =>
                      g.courseId === course.id &&
                      g.itemName
                        .toLowerCase()
                        .includes(assign.name.slice(0, 8).toLowerCase())
                  );
                  if (!hasGrade) {
                    missingAssignments.push({
                      courseId: course.id,
                      courseName: course.shortname || "Курс",
                      name: assign.name,
                      dueDate: new Date(assign.duedate * 1000).toISOString(),
                      daysOverdue,
                    });
                  }
                }
              }
            }
          }
        } catch {}
      })
    );
  } catch {}

  return { grades, missingAssignments };
}

function mapEventType(t: string): Task["type"] {
  if (t === "assign") return "deadline";
  if (t === "quiz") return "exam";
  return "deadline";
}

// ── Веб-форма логин (совместимо с React Native fetch) ────────────────────────
// React Native не поддерживает redirect: "manual" — fetch всегда следует
// редиректам автоматически. Определяем успех по финальному URL и HTML.

export async function formLogin(
  username: string,
  password: string
): Promise<boolean> {
  jar.clear();

  // Шаг 1: GET /login/index.php — получаем logintoken
  let loginToken = "";
  try {
    const loginPageRes = await fetch(`${BASE}/login/index.php`, {
      headers: HEADERS,
    });
    jar.set(loginPageRes.headers.get("set-cookie"));
    const loginHtml = await loginPageRes.text();
    loginToken =
      loginHtml.match(/name="logintoken"\s+value="([^"]+)"/)?.[1] ?? "";
  } catch {
    // Если не смогли получить страницу — проблема с сетью
    throw new Error("Не удалось подключиться к серверу");
  }

  // Шаг 2: POST учётных данных (React Native следует редиректам автоматически)
  const body = new URLSearchParams();
  body.append("username", username);
  body.append("password", password);
  if (loginToken) body.append("logintoken", loginToken);
  body.append("anchor", "");

  let postRes: Response;
  try {
    postRes = await fetch(`${BASE}/login/index.php`, {
      method: "POST",
      headers: {
        ...HEADERS,
        "Content-Type": "application/x-www-form-urlencoded",
        ...(jar.header() ? { Cookie: jar.header() } : {}),
      },
      body: body.toString(),
    });
  } catch {
    throw new Error("Не удалось подключиться к серверу");
  }

  // Сохраняем куки финального ответа
  jar.set(postRes.headers.get("set-cookie"));

  // Определяем результат по финальному URL (доступен в React Native)
  const finalUrl: string = (postRes as any).url ?? "";

  // Успех: нас перенаправило на дашборд или другую защищённую страницу
  if (
    finalUrl.includes("/my") ||
    finalUrl.includes("/dashboard") ||
    finalUrl.includes("/user/profile") ||
    (!finalUrl.includes("/login/index.php") && finalUrl.length > 0)
  ) {
    return true;
  }

  // Если финальный URL указывает на страницу логина — анализируем HTML
  try {
    const html = await postRes.text();

    // Признаки ошибки авторизации в HTML Moodle
    if (
      html.includes("loginerrormessage") ||
      html.includes("alert-danger") ||
      html.includes("Invalid login") ||
      html.includes("Неверный")
    ) {
      return false;
    }

    // Если нет формы логина — скорее всего вошли
    if (!html.includes('name="logintoken"') && !html.includes("loginpanel")) {
      return true;
    }
  } catch {}

  return false;
}

async function fetchMissedHours(): Promise<Record<string, number>> {
  try {
    const cookieHeader = jar.header();
    if (!cookieHeader) return {};

    const res = await fetch(`${BASE}/blocks/lkstudents/missedclass.php`, {
      headers: {
        ...HEADERS,
        Cookie: cookieHeader,
      },
    });
    const html = await res.text();
    // Если нас редиректнуло на логин — куки не работают
    if (html.includes("loginpanel") || html.includes("loginerrormessage")) {
      return {};
    }
    return parseMissedHours(html);
  } catch {
    return {};
  }
}

// ── HTML парсеры ─────────────────────────────────────────────────────────────

function parseMissedHours(html: string): Record<string, number> {
  const result: Record<string, number> = {};

  const monthPattern =
    /<(?:h[2-6]|strong|b|div[^>]*)>([^<]*(?:январ|феврал|март|апрел|ма[йя]|июн|июл|август|сентябр|октябр|ноябр|декабр)[^<]*\d{4}[^<]*)<\/(?:h[2-6]|strong|b|div)>/gi;

  let m: RegExpExecArray | null;
  const months: { name: string; index: number }[] = [];

  while ((m = monthPattern.exec(html)) !== null) {
    months.push({ name: m[1].trim(), index: m.index });
  }

  for (let i = 0; i < months.length; i++) {
    const from = months[i].index;
    const to = months[i + 1]?.index ?? html.length;
    const section = html.slice(from, to);

    const totalMatch = section.match(
      /Всего[^<]*<\/td>\s*<td[^>]*>\s*(\d+(?:[.,]\d+)?)/i
    );
    if (totalMatch) {
      const hours = parseFloat(totalMatch[1].replace(",", "."));
      if (!isNaN(hours) && hours >= 0) {
        const name = months[i].name
          .replace(/\s+/g, " ")
          .trim()
          .replace(/^[а-яё]/i, (c) => c.toUpperCase());
        result[name] = hours;
      }
    }
  }

  return result;
}

// ── Обнаружение изменений расписания ─────────────────────────────────────────

export function detectScheduleChanges(
  current: CalendarEvent[],
  previous: CalendarEvent[]
): string[] {
  const changes: string[] = [];

  for (const ev of current) {
    const prev = previous.find((p) => p.id === ev.id);
    if (!prev) {
      changes.push(`Добавлено: ${ev.name}`);
    } else if (Math.abs(prev.timestart - ev.timestart) > 3600) {
      changes.push(`Перенесено: ${ev.name}`);
    }
  }

  for (const prev of previous) {
    if (!current.find((ev) => ev.id === prev.id)) {
      changes.push(`Отменено: ${prev.name}`);
    }
  }

  return changes.slice(0, 6);
}

// ── Расчёт рисков ─────────────────────────────────────────────────────────────

export interface Risk {
  id: string;
  level: "danger" | "warning";
  icon: string;
  title: string;
  detail: string;
}

const MONTHS_RU = [
  "Январь","Февраль","Март","Апрель","Май","Июнь",
  "Июль","Август","Сентябрь","Октябрь","Ноябрь","Декабрь",
];

export function computeRisks(
  grades: MoodleGrade[],
  missedHours: Record<string, number>,
  missingAssignments: MissingAssignment[]
): Risk[] {
  const risks: Risk[] = [];
  const now = new Date();
  const key = `${MONTHS_RU[now.getMonth()]} ${now.getFullYear()}`;

  const totalMissed = Object.values(missedHours).reduce((a, b) => a + b, 0);
  const monthMissed = missedHours[key] ?? 0;

  if (monthMissed >= 20) {
    risks.push({
      id: "missed-danger",
      level: "danger",
      icon: "call-outline",
      title: "Выговор — вызов родителей",
      detail: `${monthMissed} ч. в этом месяце (${Math.round(monthMissed / 2)} пар) — превышен лимит 20 ч.`,
    });
  } else if (monthMissed >= 18) {
    risks.push({
      id: "missed-limit",
      level: "danger",
      icon: "warning-outline",
      title: "Месячный лимит превышен",
      detail: `${monthMissed} ч. из 18 допустимых · ещё ${monthMissed - 18} ч. лишних · до выговора ${Math.max(0, 20 - monthMissed)} ч.`,
    });
  } else if (monthMissed >= 12) {
    risks.push({
      id: "missed-warning",
      level: "warning",
      icon: "time-outline",
      title: "Много пропусков в этом месяце",
      detail: `${monthMissed} ч. (${Math.round(monthMissed / 2)} пар) · до лимита 18 ч. осталось ${18 - monthMissed} ч.`,
    });
  }

  const failing = grades.filter(
    (g) => g.grade !== null && g.gradeMax >= 5 && g.grade > 0 && g.grade < 3
  );
  if (failing.length > 0) {
    risks.push({
      id: "failing",
      level: "danger",
      icon: "close-circle-outline",
      title: `Двойки: ${failing.length} предм.`,
      detail: failing
        .slice(0, 3)
        .map((g) => `${g.courseName}: ${g.grade?.toFixed(0)}`)
        .join(" · "),
    });
  }

  const low = grades.filter(
    (g) => g.grade !== null && g.gradeMax >= 5 && g.grade >= 3 && g.grade < 4
  );
  if (low.length >= 3) {
    risks.push({
      id: "low-grades",
      level: "warning",
      icon: "trending-down-outline",
      title: `Тройки: ${low.length} предм.`,
      detail: "Риск не сдать сессию — нужно улучшить оценки",
    });
  }

  if (missingAssignments.length > 0) {
    const sorted = [...missingAssignments].sort(
      (a, b) => b.daysOverdue - a.daysOverdue
    );
    risks.push({
      id: "missing",
      level: missingAssignments.length >= 3 ? "danger" : "warning",
      icon: "document-text-outline",
      title: `Несданные работы: ${missingAssignments.length}`,
      detail: sorted
        .slice(0, 2)
        .map((a) => `${a.name} (+${a.daysOverdue} дн.)`)
        .join(" · "),
    });
  }

  return risks;
}

// ── Публичный API ─────────────────────────────────────────────────────────────

export async function validateMoodleLogin(
  username: string,
  password: string
): Promise<boolean> {
  // Сначала пробуем мобильный токен — самый надёжный способ
  try {
    const token = await getMobileToken(username, password);
    if (token) return true;
  } catch {}

  // Fallback: веб-форма (работает даже если мобильный API отключён)
  try {
    return await formLogin(username, password);
  } catch (e: any) {
    // Если ошибка сети — пробрасываем её пользователю
    if (e?.message?.includes("подключиться")) throw e;
    return false;
  }
}

export async function syncMoodle(
  username: string,
  password: string
): Promise<MoodleSyncResult> {
  let tasks: Task[] = [];
  let grades: MoodleGrade[] = [];
  let missingAssignments: MissingAssignment[] = [];
  let calendarEvents: CalendarEvent[] = [];
  let method: "api" | "scraping" = "scraping";

  // Пробуем мобильный API
  const token = await getMobileToken(username, password);

  if (token) {
    method = "api";
    const [t, ga, ce] = await Promise.allSettled([
      fetchTasksViaApi(token),
      fetchGradesAndAssignments(token),
      fetchCalendarEvents(token),
    ]);

    if (t.status === "fulfilled") tasks = t.value;
    if (ga.status === "fulfilled") {
      grades = ga.value.grades;
      missingAssignments = ga.value.missingAssignments;
    }
    if (ce.status === "fulfilled") calendarEvents = ce.value;
  }

  // Веб-форма для страницы пропусков
  try {
    await formLogin(username, password);
  } catch {}

  const missedHours = await fetchMissedHours();

  return { tasks, missedHours, grades, missingAssignments, calendarEvents, method };
}
